function getColorByProximity(dist) {
  if (dist < 1) return 0xff0000;
  if (dist < 2) return 0xffff00;
  return 0x00ff00;
}

function calculateDistance(p1, p2) {
  return Math.sqrt(
    Math.pow(p1.x - p2.x, 2) + Math.pow(p1.z - p2.z, 2)
  );
}
function createAgent() {
  const geometry = new THREE.CylinderGeometry(0.5, 0.5, 1.7, 32);
  const material = new THREE.MeshStandardMaterial({ color: 0x00ff00 });
  const mesh = new THREE.Mesh(geometry, material);

  mesh.position.set(
    Math.random() * 30 - 15,
    0.85,
    Math.random() * 30 - 15
  );

  return {
    mesh,
    update() {
      mesh.position.x += 0.05 * (Math.random() - 0.5);
      mesh.position.z += 0.05 * (Math.random() - 0.5);
    }
  };
}
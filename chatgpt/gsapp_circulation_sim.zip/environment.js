function loadEnvironment(scene) {
  const loader = new THREE.GLTFLoader();
  loader.load('assets/models/studio_model.glb', gltf => {
    const model = gltf.scene;
    model.scale.set(1, 1, 1);
    scene.add(model);
  });
}
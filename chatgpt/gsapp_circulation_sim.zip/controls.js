const gui = new dat.GUI();

const params = {
  peopleCount: 20,
  speed: 2,
  showTrails: true,
  colorByProximity: true
};

gui.add(params, 'peopleCount', 1, 100, 1).name('People Count');
gui.add(params, 'speed', 0.5, 5, 0.1).name('Speed');
gui.add(params, 'showTrails').name('Trail Paths');
gui.add(params, 'colorByProximity').name('Color by Proximity');